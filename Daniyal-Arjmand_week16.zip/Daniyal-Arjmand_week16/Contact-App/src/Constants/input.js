const input = [
  { type: "text", name: "Name", placeholder: "نام" },
  { type: "text", name: "LastName", placeholder: "نام خانوادگی" },
  { type: "email", name: "Email", placeholder: "ایمیل" },
  { type: "number", name: "Phone", placeholder: "شماره تلفن" },
];

export default input;
