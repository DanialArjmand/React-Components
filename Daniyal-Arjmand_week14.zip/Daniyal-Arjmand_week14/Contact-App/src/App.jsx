import React from "react";
import Home from "./Components/Home";
import "./App.css";

const App = () => {
  return (
    <div className="App">
      <Home />
    </div>
  );
};

export default App;
